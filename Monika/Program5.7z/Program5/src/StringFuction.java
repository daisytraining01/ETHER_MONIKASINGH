
public class StringFuction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	String str="REST ASSURED";
	String str1=str.replaceAll("S","");
	String str2=str.replaceAll("T", "");
	System.out.println(str2);
	
	/*For String compare please input the name and name2 it will return boolean*/
	String name="Monika";
	String newname="Monika";
	int compare=name.compareTo(newname);
	System.out.println(compare);	
}
}

//output
//RET AURED
//0