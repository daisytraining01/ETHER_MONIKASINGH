import java.io.*;

public class FileReaderPrint {
	public static void main(String[] args) throws Exception {
		File file = new File("C:\\Users\\monika\\Desktop\\test.txt");

		BufferedReader br = new BufferedReader(new FileReader(file));

		String st;
		int n = 0;
		while ((st = br.readLine()) != null) {
			if (n % 2 == 0) {
				System.out.println(st);
				System.out.println("print");
			} else {
				System.out.println(st);
			}

		}
	}
}

//output
//Hi everyone
//print
//this 
//print
//is
//print
//monika singh
//print
//and i am doing great
//print