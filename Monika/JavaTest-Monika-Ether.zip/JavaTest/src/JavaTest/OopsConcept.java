package JavaTest;
public class OopsConcept {
  int x; 

  // Create a class constructor for the MyClass class
  public OopsConcept() {
    x = 5;  
  }
  private String empName;
  private int empAge;

  public String getEmpName(){
      return empName;
  }

  public int getEmpAge(){
      return empAge;
  }

  public void setEmpAge(int newValue){
      empAge = newValue;
  }
  
  public void setEmpName(String newValue){
      empName = newValue;
  }
  String designation = "Teacher";
  String collegeName = "Beginnersbook";
  void does(){
	System.out.println("Teaching");
  }
}