package JavaTest;

public class OopsInheritence extends OopsConcept {
		String mainSubject = "Physics";
	public static void main(String[] args) {
		
		// Create an object of class MyClass (This will call the constructor)
		OopsInheritence myObj = new OopsInheritence(); 
	    System.out.println("Constructor: "+myObj.x);
	    
	    
	    /*this is for encapsulation*/
	    myObj.setEmpName("Monika");
	    myObj.setEmpAge(25);
	    System.out.println("Encapsulation Demo Employee Name: " + myObj.getEmpName());
	    System.out.println("Encapsulation Demo Employee Age: " + myObj.getEmpAge());
	    
	    /*this is for inheritence*/
	    System.out.println("Inheritence: "+myObj.collegeName);
		System.out.println("Inheritence: "+myObj.designation);
		System.out.println("Inheritence: "+myObj.mainSubject);
		myObj.does();	   
}
}

//output
//Constructor: 5
//Encapsulation Demo Employee Name: Monika
//Encapsulation Demo Employee Age: 25
//Inheritence: Beginnersbook
//Inheritence: Teacher
//Inheritence: Physics
//Teaching


