package JavaTest;
public class Palindrome {

	// Function that returns true if string is a palindrome
	static boolean isPalindrome(String str) {
		int i = 0, j = str.length() - 1;
		while (i < j) {
			if (str.charAt(i) != str.charAt(j))
				return false;
			i++;
			j--;
		}
		return true;
	}

	public static void main(String[] args) {
		String str = "monika"; // to check for palindrome use this aabbaa

		if (isPalindrome(str))
			System.out.print("Yes");
		else
			System.out.print("No");
	}
}

//ouput
//yes for string aabbaa
//no for string monica