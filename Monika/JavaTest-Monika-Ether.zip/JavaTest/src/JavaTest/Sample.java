package JavaTest;
class Sample implements MyInterface {
	public void method1() {
		System.out.println("implementation of method1");
	}

	public void method2() {
		System.out.println("implementation of method2");
	}

	public static void main(String args[]) {
		ExampleOverloading obj = new ExampleOverloading();
		obj.disp('a');
		obj.disp('a', 10);

		MyInterface obj1 = new Sample();
		obj1.method1();
	}
}

//output for overloading
//a
//a 10
//output for interface
//implementation of method1